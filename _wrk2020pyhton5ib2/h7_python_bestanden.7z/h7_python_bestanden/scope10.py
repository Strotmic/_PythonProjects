'''Dit is de docstring voor de module'''

for a in range(5):
    if a == 4:
        print(a, '-> a in for-loop')
print(a, '-> a in global')
