'''Dit is de docstring voor de module'''

def berekening():
    '''Dit is de docstring voor de functie'''
    cost = 100
    cost = str(100) + " dollars"
    print(cost)

berekening()
