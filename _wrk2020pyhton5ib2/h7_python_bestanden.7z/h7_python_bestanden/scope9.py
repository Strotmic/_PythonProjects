'''Dit is de docstring voor de module'''

a_var = 2

def a_func(some_var):
    return 2**3

a_var = a_func(a_var)
print(a_var)
