'''Dit is de docstring voor de module'''

i = 1
print([i for i in range(5)])
print(i, '-> i in global')
