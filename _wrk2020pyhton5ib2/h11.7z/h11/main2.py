import main1

print("doe nu de rest")
