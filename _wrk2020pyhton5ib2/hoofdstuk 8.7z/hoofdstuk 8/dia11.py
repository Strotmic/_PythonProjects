punten = 25

if punten>=50:
  print(" je bent geslaagd")
else :
  print("niet geslaagd")