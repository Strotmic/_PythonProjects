'''Dit is de docstring voor de module'''
from tkinter import Tk, Label
from tkinter import messagebox
from tkinter import simpledialog


window = Tk()
w = Label(window, text= "Mijn programma")
w.pack()
