from simpleutils.simpledialogs import messagebox, simpledialog


while True:
  
  getal = simpledialog.askinteger("BesturingD", "Geef een getal op")

  if getal>0:
    break