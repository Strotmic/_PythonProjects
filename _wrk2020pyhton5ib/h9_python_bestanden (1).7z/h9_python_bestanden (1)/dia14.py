def square(x):
    return x*x

print(square(4))