def adder(x, y, z):
    print("sum:", x + y + z)


adder(10, 5, 20)


# adder(5, 10, 15, 20, 25)
