def multiply(x,y):
    print(x*y)

multiply(2,8)