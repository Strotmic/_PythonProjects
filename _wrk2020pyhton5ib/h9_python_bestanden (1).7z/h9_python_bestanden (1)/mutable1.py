list1 = ['a', 'b', 'c']

print(list1)
print(id(list1))

list1[2] = 'x'
print(list1)
print(id(list1))
