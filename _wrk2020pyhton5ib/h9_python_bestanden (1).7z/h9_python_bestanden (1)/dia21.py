def h(lijst):
    lijst[0]=5


lst = [1,2,3]
h(lst)
print(lst)
