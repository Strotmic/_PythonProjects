x = 10
y = x 

print(x)
print(id(x))
print(y)
print(id(y))

x = x + 1

print(x)
print(id(x))
print(y)
print(id(y))
