def g(x):
    return 2*x

a=3
print(g(a))
print(a)
