from Bag import Bag

def x():
    objmens = Bag()
    objmens.bereken_bag()
    objmens.dronken()
x()